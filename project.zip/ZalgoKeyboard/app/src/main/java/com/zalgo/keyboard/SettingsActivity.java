package com.zalgo.keyboard;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends Activity {
    private TextView preview;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        final SharedPreferences sp = getSharedPreferences("zalgo", MODE_PRIVATE);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView t = new TextView(this);
        t.setText("Kitne marks lagane hain? (1 se 1000)");
        t.setTextSize(18);
        root.addView(t);

        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setText(String.valueOf(sp.getInt("count", 25)));
        root.addView(et);

        TextView t2 = new TextView(this);
        t2.setText("Design:");
        t2.setTextSize(18);
        t2.setPadding(0, pad / 2, 0, 0);
        root.addView(t2);

        final Spinner spin = new Spinner(this);
        spin.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, Designs.NAMES));
        spin.setSelection(sp.getInt("design", 0));
        root.addView(spin);

        TextView t3 = new TextView(this);
        t3.setText("Font:");
        t3.setTextSize(18);
        t3.setPadding(0, pad / 2, 0, 0);
        root.addView(t3);

        final Spinner fspin = new Spinner(this);
        fspin.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, Fonts.NAMES));
        fspin.setSelection(sp.getInt("font", 0));
        root.addView(fspin);

        Button save = new Button(this);
        save.setText("Save");
        root.addView(save);

        preview = new TextView(this);
        preview.setTextSize(36);
        preview.setPadding(0, pad, 0, pad);
        root.addView(preview);
        updatePreview(sp.getInt("font", 0), sp.getInt("design", 0), sp.getInt("count", 25));

        save.setOnClickListener(v -> {
            int n = 25;
            try { n = Integer.parseInt(et.getText().toString().trim()); } catch (Exception ignored) {}
            if (n < 1) n = 1;
            if (n > 1000) n = 1000;
            et.setText(String.valueOf(n));
            int d = spin.getSelectedItemPosition();
            int f = fspin.getSelectedItemPosition();
            sp.edit().putInt("count", n).putInt("design", d).putInt("font", f).apply();
            updatePreview(f, d, n);
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
        });

        Button enable = new Button(this);
        enable.setText("1) Keyboard enable karo");
        enable.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        root.addView(enable);

        Button pick = new Button(this);
        pick.setText("2) Keyboard chuno");
        pick.setOnClickListener(v -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.showInputMethodPicker();
        });
        root.addView(pick);

        setContentView(scroll);
    }

    private void updatePreview(int font, int design, int n) {
        int m = Math.min(n, 60);
        String ch = Designs.chain(design, m);
        preview.setText(Fonts.map('a', font) + ch + "  " + Fonts.map('b', font) + ch);
    }
}
