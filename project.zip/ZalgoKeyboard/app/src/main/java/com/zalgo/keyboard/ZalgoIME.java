package com.zalgo.keyboard;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import java.util.ArrayList;
import java.util.List;

public class ZalgoIME extends InputMethodService {
    private static final int BG = 0xFF1B1C1F;
    private static final int KEY = 0xFF2D2F33;
    private static final int SPECIAL = 0xFF3A4254;
    private static final int ACCENT = 0xFF4B5D88;
    private static final int KEY_ON = 0xFF5F6B85;
    private static final int KEY_H = 54;
    private static final int PAGE_H = 5 * (KEY_H + 4);

    private static final String[] EMOJIS = {
        "😀", "😂", "🥹", "😍", "🥰", "😘", "😎", "🤩",
        "🥳", "😭", "😢", "😡", "🤔", "🙄", "😴", "🤯",
        "😈", "💀", "👻", "🤡", "👍", "👎", "👏", "🙏",
        "💪", "🤝", "✌️", "🤞", "👌", "🫶", "❤️", "🧡",
        "💛", "💚", "💙", "💜", "🖤", "🤍", "💔", "💯",
        "🔥", "✨", "⭐", "🌙", "☀️", "🌈", "🎉", "🎂",
        "🎁", "🎵", "👀", "🌹", "🍕", "☕", "🫦", "😏"
    };

    private boolean zalgoOn = true;
    private int shiftState = 0; // 0 off, 1 once, 2 lock
    private long lastShiftTap = 0;

    private Button zBtn, designTop, fontTop, shiftBtn;
    private final List<Button> letterBtns = new ArrayList<>();
    private final List<Button> designBtns = new ArrayList<>();
    private final List<Button> fontBtns = new ArrayList<>();
    private View lettersPage, symbolsPage, designPage, fontPage, emojiPage;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private int repeatCount = 0;
    private final Runnable repeater = new Runnable() {
        @Override
        public void run() {
            deleteCluster();
            repeatCount++;
            long delay = repeatCount > 12 ? 35 : (repeatCount > 5 ? 60 : 100);
            handler.postDelayed(this, delay);
        }
    };

    private SharedPreferences prefs() {
        return getSharedPreferences("zalgo", MODE_PRIVATE);
    }

    private int design() { return prefs().getInt("design", 0); }
    private int font() { return prefs().getInt("font", 0); }

    @Override
    public boolean onEvaluateFullscreenMode() {
        return false;
    }

    @Override
    public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        if (lettersPage != null) {
            showPage(lettersPage);
            refreshToolbar();
            refreshDesignButtons();
            refreshFontButtons();
        }
    }

    @Override
    public void onFinishInputView(boolean finishingInput) {
        super.onFinishInputView(finishingInput);
        handler.removeCallbacks(repeater);
    }

    // ---------- UI ----------

    @Override
    public View onCreateInputView() {
        letterBtns.clear();
        designBtns.clear();
        fontBtns.clear();
        shiftState = 0;

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        int p = dp(4);
        root.setPadding(p, p, p, p);

        root.addView(buildToolbar());

        FrameLayout frame = new FrameLayout(this);
        lettersPage = buildLetters();
        symbolsPage = buildSymbols();
        designPage = buildDesignPage();
        fontPage = buildFontPage();
        emojiPage = buildEmojiPage();
        frame.addView(lettersPage);
        frame.addView(symbolsPage);
        frame.addView(designPage);
        frame.addView(fontPage);
        frame.addView(emojiPage);
        root.addView(frame);

        showPage(lettersPage);
        refreshToolbar();
        return root;
    }

    private View buildToolbar() {
        LinearLayout t = new LinearLayout(this);
        t.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));
        zBtn = pill("Z:ON", 1f, 13, v -> {
            zalgoOn = !zalgoOn;
            refreshToolbar();
        });
        designTop = pill("Design 1", 1.3f, 13, v -> showPage(designPage));
        fontTop = pill("Font: Normal", 1.7f, 13, v -> showPage(fontPage));
        t.addView(zBtn);
        t.addView(designTop);
        t.addView(fontTop);
        return t;
    }

    private Button pill(String label, float weight, int sp, View.OnClickListener l) {
        Button b = baseBtn(label, sp, KEY, 22, l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(38), weight);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        b.setLayoutParams(lp);
        return b;
    }

    private LinearLayout page() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(PAGE_H)));
        return l;
    }

    private View buildLetters() {
        LinearLayout pg = page();
        pg.addView(row("1234567890", 0f));
        pg.addView(row("qwertyuiop", 0f));
        pg.addView(row("asdfghjkl", 0.5f));

        LinearLayout r4 = new LinearLayout(this);
        shiftBtn = key("⇧", 1.5f, SPECIAL, 20, v -> onShift());
        r4.addView(shiftBtn);
        for (char c : "zxcvbnm".toCharArray()) r4.addView(charKey(c));
        r4.addView(deleteKey(1.5f));
        pg.addView(r4);

        pg.addView(bottomRow("?123", v -> showPage(symbolsPage)));
        return pg;
    }

    private View buildSymbols() {
        LinearLayout pg = page();
        pg.addView(symRow("1234567890", 0f));
        pg.addView(symRow("@#$%&-+()/", 0f));
        pg.addView(symRow("~`|<>{}[]\\", 0f));
        LinearLayout r4 = new LinearLayout(this);
        for (char c : "*\":;!?_=".toCharArray()) r4.addView(symKey(c));
        r4.addView(deleteKey(2f));
        pg.addView(r4);
        pg.addView(bottomRow("ABC", v -> showPage(lettersPage)));
        return pg;
    }

    private LinearLayout bottomRow(String toggleLabel, View.OnClickListener toggle) {
        LinearLayout r = new LinearLayout(this);
        r.addView(key(toggleLabel, 1.5f, SPECIAL, 15, toggle, 24));
        r.addView(key(",", 1f, SPECIAL, 22, v -> commit(",")));
        r.addView(key("😊", 1f, KEY, 20, v -> showPage(emojiPage)));
        r.addView(key("space", 5f, KEY, 15, v -> commit(" ")));
        r.addView(key(".", 1f, SPECIAL, 22, v -> commit(".")));
        r.addView(key("↵", 1.5f, ACCENT, 22, v -> enter(), 24));
        return r;
    }

    private View buildEmojiPage() {
        LinearLayout pg = page();
        LinearLayout head = new LinearLayout(this);
        head.addView(key("ABC", 1.5f, SPECIAL, 15, v -> showPage(lettersPage), 24));
        head.addView(spacer(6f));
        head.addView(deleteKey(1.5f));
        pg.addView(head);

        ScrollView sv = new ScrollView(this);
        sv.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout cur = null;
        for (int i = 0; i < EMOJIS.length; i++) {
            if (i % 8 == 0) {
                cur = new LinearLayout(this);
                grid.addView(cur);
            }
            final String e = EMOJIS[i];
            cur.addView(key(e, 1f, KEY, 22, v -> commit(e)));
        }
        sv.addView(grid);
        pg.addView(sv);
        return pg;
    }

    private View buildDesignPage() {
        ScrollView sv = new ScrollView(this);
        sv.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(PAGE_H)));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.addView(listBtn("← Wapas (design chuno)", v -> showPage(lettersPage)));
        for (int i = 0; i < Designs.NAMES.length; i++) {
            final int idx = i;
            Button b = listBtn("", v -> selectDesign(idx));
            designBtns.add(b);
            list.addView(b);
        }
        refreshDesignButtons();
        sv.addView(list);
        return sv;
    }

    private View buildFontPage() {
        ScrollView sv = new ScrollView(this);
        sv.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(PAGE_H)));
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.addView(listBtn("← Wapas (font chuno)", v -> showPage(lettersPage)));
        for (int i = 0; i < Fonts.NAMES.length; i++) {
            final int idx = i;
            Button b = listBtn("", v -> selectFont(idx));
            fontBtns.add(b);
            list.addView(b);
        }
        refreshFontButtons();
        sv.addView(list);
        return sv;
    }

    private Button listBtn(String label, View.OnClickListener l) {
        Button b = baseBtn(label, 16, KEY, 10, l);
        b.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        b.setPadding(dp(14), 0, dp(14), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46));
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        b.setLayoutParams(lp);
        return b;
    }

    private void showPage(View target) {
        View[] all = {lettersPage, symbolsPage, designPage, fontPage, emojiPage};
        for (View v : all) {
            if (v != null) v.setVisibility(v == target ? View.VISIBLE : View.GONE);
        }
    }

    private void refreshToolbar() {
        if (zBtn == null) return;
        zBtn.setText(zalgoOn ? "Z:ON" : "Z:OFF");
        zBtn.setBackground(bg(zalgoOn ? ACCENT : KEY, 22));
        designTop.setText("Design " + (design() + 1));
        int f = Math.min(font(), Fonts.SHORT.length - 1);
        fontTop.setText("Font: " + Fonts.SHORT[f]);
    }

    private void selectDesign(int i) {
        prefs().edit().putInt("design", i).apply();
        refreshDesignButtons();
        refreshToolbar();
        showPage(lettersPage);
    }

    private void selectFont(int i) {
        prefs().edit().putInt("font", i).apply();
        refreshFontButtons();
        refreshToolbar();
        showPage(lettersPage);
    }

    private void refreshDesignButtons() {
        int cur = design();
        for (int i = 0; i < designBtns.size(); i++) {
            Button b = designBtns.get(i);
            b.setText((i == cur ? "✓ " : "") + (i + 1) + ". " + Designs.NAMES[i]);
            b.setBackground(bg(i == cur ? KEY_ON : KEY, 10));
        }
    }

    private void refreshFontButtons() {
        int cur = font();
        for (int i = 0; i < fontBtns.size(); i++) {
            Button b = fontBtns.get(i);
            b.setText((i == cur ? "✓ " : "") + Fonts.NAMES[i] + "    " + Fonts.sample(i));
            b.setBackground(bg(i == cur ? KEY_ON : KEY, 10));
        }
    }

    // ---------- keys ----------

    private LinearLayout row(String chars, float pad) {
        LinearLayout r = new LinearLayout(this);
        if (pad > 0) r.addView(spacer(pad));
        for (char c : chars.toCharArray()) r.addView(charKey(c));
        if (pad > 0) r.addView(spacer(pad));
        return r;
    }

    private LinearLayout symRow(String chars, float pad) {
        LinearLayout r = new LinearLayout(this);
        for (char c : chars.toCharArray()) {
            r.addView(Character.isDigit(c) ? charKey(c) : symKey(c));
        }
        return r;
    }

    private View spacer(float w) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(0, dp(KEY_H), w));
        return v;
    }

    private Button charKey(final char c) {
        Button b = key(String.valueOf(c), 1f, KEY, 24, v -> typeChar(c));
        if (Character.isLetter(c)) letterBtns.add(b);
        return b;
    }

    private Button symKey(final char c) {
        return key(String.valueOf(c), 1f, KEY, 22, v -> commit(String.valueOf(c)));
    }

    private Button key(String label, float weight, int color, int sp, View.OnClickListener l) {
        return key(label, weight, color, sp, l, 10);
    }

    private Button key(String label, float weight, int color, int sp,
                       View.OnClickListener l, int radius) {
        Button b = baseBtn(label, sp, color, radius, l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(KEY_H), weight);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        b.setLayoutParams(lp);
        return b;
    }

    private Button baseBtn(String label, int sp, int color, int radius, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setPadding(0, 0, 0, 0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setSingleLine(true);
        b.setEllipsize(null);
        b.setIncludeFontPadding(false);
        b.setStateListAnimator(null);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        b.setTextColor(Color.WHITE);
        b.setBackground(bg(color, radius));
        b.setGravity(Gravity.CENTER);
        if (l != null) b.setOnClickListener(l);
        return b;
    }

    private StateListDrawable bg(int color, int radiusDp) {
        GradientDrawable n = new GradientDrawable();
        n.setColor(color);
        n.setCornerRadius(dp(radiusDp));
        GradientDrawable p = new GradientDrawable();
        p.setColor(lighten(color));
        p.setCornerRadius(dp(radiusDp));
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, p);
        s.addState(new int[]{}, n);
        return s;
    }

    private int lighten(int c) {
        return Color.rgb(Math.min(255, Color.red(c) + 45),
                Math.min(255, Color.green(c) + 45),
                Math.min(255, Color.blue(c) + 45));
    }

    @SuppressWarnings("ClickableViewAccessibility")
    private Button deleteKey(float weight) {
        Button b = key("⌫", weight, SPECIAL, 22, null, 10);
        b.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    v.setPressed(true);
                    deleteCluster();
                    repeatCount = 0;
                    handler.removeCallbacks(repeater);
                    handler.postDelayed(repeater, 400);
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    v.setPressed(false);
                    handler.removeCallbacks(repeater);
                    return true;
            }
            return true;
        });
        return b;
    }

    // ---------- shift / typing ----------

    private void onShift() {
        long now = System.currentTimeMillis();
        if (shiftState == 2) {
            shiftState = 0;
        } else if (shiftState == 1 && now - lastShiftTap < 350) {
            shiftState = 2;
        } else {
            shiftState = (shiftState == 0) ? 1 : 0;
        }
        lastShiftTap = now;
        refreshCase();
    }

    private void refreshCase() {
        boolean up = shiftState > 0;
        for (Button b : letterBtns) {
            String s = b.getText().toString();
            b.setText(up ? s.toUpperCase() : s.toLowerCase());
        }
        shiftBtn.setText(shiftState == 2 ? "⇪" : "⇧");
        shiftBtn.setBackground(bg(shiftState == 0 ? SPECIAL : (shiftState == 1 ? KEY_ON : ACCENT), 10));
    }

    private String chain() {
        int n = Math.max(1, Math.min(1000, prefs().getInt("count", 25)));
        return Designs.chain(design(), n);
    }

    private void typeChar(char c) {
        if (Character.isLetter(c)) {
            char ch = shiftState > 0 ? Character.toUpperCase(c) : c;
            String s = Fonts.map(ch, font());
            if (zalgoOn) s += chain();
            commit(s);
            if (shiftState == 1) {
                shiftState = 0;
                refreshCase();
            }
        } else if (Character.isDigit(c)) {
            String s = Fonts.map(c, font());
            if (zalgoOn) s += chain();
            commit(s);
        } else {
            commit(String.valueOf(c));
        }
    }

    private void commit(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) ic.commitText(s, 1);
    }

    private void enter() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        EditorInfo ei = getCurrentInputEditorInfo();
        if (ei != null && (ei.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) == 0) {
            int a = ei.imeOptions & EditorInfo.IME_MASK_ACTION;
            if (a == EditorInfo.IME_ACTION_GO || a == EditorInfo.IME_ACTION_SEARCH
                    || a == EditorInfo.IME_ACTION_SEND || a == EditorInfo.IME_ACTION_DONE
                    || a == EditorInfo.IME_ACTION_NEXT) {
                ic.performEditorAction(a);
                return;
            }
        }
        sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER);
    }

    // Ek tap = ek poora letter (uske saare marks ke saath) delete
    private void deleteCluster() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;

        CharSequence sel = ic.getSelectedText(0);
        if (sel != null && sel.length() > 0) {
            ic.commitText("", 1);
            return;
        }

        CharSequence before = ic.getTextBeforeCursor(3000, 0);
        if (before == null || before.length() == 0) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL);
            return;
        }
        String s = before.toString();
        int end = s.length();
        int i = end;
        while (i > 0) {
            int cp = s.codePointBefore(i);
            int t = Character.getType(cp);
            if (t == Character.NON_SPACING_MARK
                    || t == Character.ENCLOSING_MARK
                    || t == Character.COMBINING_SPACING_MARK) {
                i -= Character.charCount(cp);
            } else {
                break;
            }
        }
        if (i > 0) {
            i -= Character.charCount(s.codePointBefore(i));
        }
        ic.deleteSurroundingText(end - i, 0);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }
}
