package com.zalgo.keyboard;

public class Fonts {
    public static final String[] NAMES = {
        "Normal", "Bold", "Italic", "Bold Italic", "Script", "Bold Script",
        "Fraktur", "Bold Fraktur", "Double-struck", "Monospace", "Sans",
        "Sans Bold", "Sans Italic", "Sans Bold Italic", "Circled", "Fullwidth", "Small Caps"
    };

    public static final String[] SHORT = {
        "Normal", "Bold", "Italic", "B-Italic", "Script", "B-Script",
        "Fraktur", "B-Fraktur", "Double", "Mono", "Sans",
        "S-Bold", "S-Italic", "S-BI", "Circle", "Wide", "SmCaps"
    };

    private static final int[] LOWER = {
        0, 0x1D41A, 0x1D44E, 0x1D482, 0x1D4B6, 0x1D4EA, 0x1D51E, 0x1D586,
        0x1D552, 0x1D68A, 0x1D5BA, 0x1D5EE, 0x1D622, 0x1D656, 0x24D0, 0xFF41, 0
    };
    private static final int[] UPPER = {
        0, 0x1D400, 0x1D434, 0x1D468, 0x1D49C, 0x1D4D0, 0x1D504, 0x1D56C,
        0x1D538, 0x1D670, 0x1D5A0, 0x1D5D4, 0x1D608, 0x1D63C, 0x24B6, 0xFF21, 0
    };
    private static final int[] DIGIT = {
        0, 0x1D7CE, -1, -1, -1, -1, -1, -1,
        0x1D7D8, 0x1D7F6, 0x1D7E2, 0x1D7EC, -1, -1, -2, 0xFF10, -1
    };

    private static final char[] SMALL = {
        '\u1D00', '\u0299', '\u1D04', '\u1D05', '\u1D07', '\uA730', '\u0262', '\u029C',
        '\u026A', '\u1D0A', '\u1D0B', '\u029F', '\u1D0D', '\u0274', '\u1D0F', '\u1D18',
        '\u01EB', '\u0280', '\uA731', '\u1D1B', '\u1D1C', '\u1D20', '\u1D21', 'x',
        '\u028F', '\u1D22'
    };

    private static int exception(int f, char c) {
        switch (f) {
            case 2:
                if (c == 'h') return 0x210E;
                break;
            case 4:
                switch (c) {
                    case 'B': return 0x212C;
                    case 'E': return 0x2130;
                    case 'F': return 0x2131;
                    case 'H': return 0x210B;
                    case 'I': return 0x2110;
                    case 'L': return 0x2112;
                    case 'M': return 0x2133;
                    case 'R': return 0x211B;
                    case 'e': return 0x212F;
                    case 'g': return 0x210A;
                    case 'o': return 0x2134;
                }
                break;
            case 6:
                switch (c) {
                    case 'C': return 0x212D;
                    case 'H': return 0x210C;
                    case 'I': return 0x2111;
                    case 'R': return 0x211C;
                    case 'Z': return 0x2128;
                }
                break;
            case 8:
                switch (c) {
                    case 'C': return 0x2102;
                    case 'H': return 0x210D;
                    case 'N': return 0x2115;
                    case 'P': return 0x2119;
                    case 'Q': return 0x211A;
                    case 'R': return 0x211D;
                    case 'Z': return 0x2124;
                }
                break;
        }
        return 0;
    }

    private static String cp(int code) {
        return new String(Character.toChars(code));
    }

    public static String map(char c, int f) {
        if (f <= 0 || f >= NAMES.length) return String.valueOf(c);
        if (c >= 'a' && c <= 'z') {
            if (f == 16) return String.valueOf(SMALL[c - 'a']);
            int ex = exception(f, c);
            if (ex != 0) return cp(ex);
            return cp(LOWER[f] + (c - 'a'));
        }
        if (c >= 'A' && c <= 'Z') {
            if (f == 16) return String.valueOf(c);
            int ex = exception(f, c);
            if (ex != 0) return cp(ex);
            return cp(UPPER[f] + (c - 'A'));
        }
        if (c >= '0' && c <= '9') {
            if (f == 14) return c == '0' ? "\u24EA" : String.valueOf((char) (0x2460 + (c - '1')));
            int b = DIGIT[f];
            if (b <= 0) return String.valueOf(c);
            return cp(b + (c - '0'));
        }
        return String.valueOf(c);
    }

    public static String sample(int f) {
        StringBuilder sb = new StringBuilder();
        for (char c : "Hello 123".toCharArray()) sb.append(map(c, f));
        return sb.toString();
    }
}
